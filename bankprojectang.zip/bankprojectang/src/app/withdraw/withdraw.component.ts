import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  amount: number;
  constructor(private customerService:CustomerServiceService) { }
  ngOnInit() {
  }
  withdrawAmount(accnum,amount){
  this.customerService.withdrawAmount(accnum,amount).subscribe(data => {
  this.amount = data;
  });
 }
}
