import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  amount: number;
  constructor(private customerService:CustomerServiceService) { }
  ngOnInit() {
  }
  depositAmount(accnum,amount){
  this.customerService.depositAmount(accnum,amount).subscribe(data => {
  this.amount = data;
  });
 }
}
