import { Component, OnInit } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';

@Component({
  selector: 'app-cash-transfer',
  templateUrl: './cash-transfer.component.html',
  styleUrls: ['./cash-transfer.component.css']
})
export class CashTransferComponent implements OnInit {

  constructor(private customerService: CustomerServiceService) { }
  balance:number;
  ngOnInit() {
  }

  cashTransfer(accountNo,recaccountNo,amount)
 { 
this.customerService.cashTransfer(accountNo,recaccountNo,amount).subscribe(data => {
this.balance = data;
 });
}
}
